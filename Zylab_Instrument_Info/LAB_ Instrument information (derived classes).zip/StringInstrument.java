// TODO: Define a class: StringInstrument that is derived from the Instrument class
public class StringInstrument extends Instrument {
   // TODO: Declare private fields: numStrings, numFrets

   // TODO: Define mutator methods - 
   //      setNumOfStrings(), setNumOfFrets()

   // TODO: Define accessor methods -
   //      getNumOfStrings(), getNumOfFrets()

}

